/* SPDX-FileCopyrightText: 2025 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <glib.h>
#include "gtksourceview/gtksourceencoding.h"

G_BEGIN_DECLS

G_GNUC_INTERNAL
gboolean	_gtk_source_encoding_conversion_try_convert	(const GtkSourceEncoding *from_encoding,
								 const gchar             *input_buffer,
								 gsize                    input_buffer_size);

G_END_DECLS
