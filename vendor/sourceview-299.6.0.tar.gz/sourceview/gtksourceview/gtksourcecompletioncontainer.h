/* SPDX-FileCopyrightText: 2013 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define GTK_SOURCE_TYPE_COMPLETION_CONTAINER             (_gtk_source_completion_container_get_type ())
#define GTK_SOURCE_COMPLETION_CONTAINER(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), GTK_SOURCE_TYPE_COMPLETION_CONTAINER, GtkSourceCompletionContainer))
#define GTK_SOURCE_COMPLETION_CONTAINER_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), GTK_SOURCE_TYPE_COMPLETION_CONTAINER, GtkSourceCompletionContainerClass)
#define GTK_SOURCE_IS_COMPLETION_CONTAINER(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTK_SOURCE_TYPE_COMPLETION_CONTAINER))
#define GTK_SOURCE_IS_COMPLETION_CONTAINER_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), GTK_SOURCE_TYPE_COMPLETION_CONTAINER))
#define GTK_SOURCE_COMPLETION_CONTAINER_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), GTK_SOURCE_TYPE_COMPLETION_CONTAINER, GtkSourceCompletionContainerClass))

typedef struct _GtkSourceCompletionContainer       GtkSourceCompletionContainer;
typedef struct _GtkSourceCompletionContainerClass  GtkSourceCompletionContainerClass;

struct _GtkSourceCompletionContainer
{
	GtkScrolledWindow parent;
};

struct _GtkSourceCompletionContainerClass
{
	GtkScrolledWindowClass parent_class;
};

G_GNUC_INTERNAL
GType		 _gtk_source_completion_container_get_type		(void) G_GNUC_CONST;

G_GNUC_INTERNAL
GtkSourceCompletionContainer *
		 _gtk_source_completion_container_new			(void);

G_END_DECLS
