/* SPDX-FileCopyrightText: 2013 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#if !defined (GTK_SOURCE_H_INSIDE) && !defined (GTK_SOURCE_COMPILATION)
#error "Only <gtksourceview/gtksource.h> can be included directly."
#endif

#include <gtksourceview/gtksourcebuffer.h>

G_BEGIN_DECLS

G_MODULE_EXPORT
gchar *		gtk_source_utils_unescape_search_text		(const gchar *text);

G_MODULE_EXPORT
gchar *		gtk_source_utils_escape_search_text		(const gchar *text);

G_MODULE_EXPORT
gchar *		gtk_source_utils_get_bracket_matched_message	(GtkTextIter               *iter,
								 GtkSourceBracketMatchType  state);

G_END_DECLS
