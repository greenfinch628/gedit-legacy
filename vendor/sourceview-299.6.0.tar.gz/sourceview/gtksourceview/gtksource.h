/* SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#define GTK_SOURCE_H_INSIDE

#include <gtksourceview/completion-providers/words/gtksourcecompletionwords.h>
#include <gtksourceview/file-loading-and-saving/gtksourceiconv.h>
#include <gtksourceview/file-loading-and-saving/gtksourceinputstream.h>
#include <gtksourceview/gtksourcetypes.h>
#include <gtksourceview/gtksourcebuffer.h>
#include <gtksourceview/gtksourcecompletioncontext.h>
#include <gtksourceview/gtksourcecompletion.h>
#include <gtksourceview/gtksourcecompletioninfo.h>
#include <gtksourceview/gtksourcecompletionitem.h>
#include <gtksourceview/gtksourcecompletionproposal.h>
#include <gtksourceview/gtksourcecompletionprovider.h>
#include <gtksourceview/gtksourceencoding.h>
#include <gtksourceview/gtksourcefile.h>
#include <gtksourceview/gtksourcefileloader.h>
#include <gtksourceview/gtksourcefilesaver.h>
#include <gtksourceview/gtksourcegutter.h>
#include <gtksourceview/gtksourcegutterrenderer.h>
#include <gtksourceview/gtksourcegutterrenderertext.h>
#include <gtksourceview/gtksourcegutterrendererpixbuf.h>
#include <gtksourceview/gtksourceinit.h>
#include <gtksourceview/gtksourceiter.h>
#include <gtksourceview/gtksourcelanguage.h>
#include <gtksourceview/gtksourcelanguagemanager.h>
#include <gtksourceview/gtksourcemark.h>
#include <gtksourceview/gtksourcemarkattributes.h>
#include <gtksourceview/gtksourceprintcompositor.h>
#include <gtksourceview/gtksourceregion.h>
#include <gtksourceview/gtksourcesearchcontext.h>
#include <gtksourceview/gtksourcesearchsettings.h>
#include <gtksourceview/gtksourcespacedrawer.h>
#include <gtksourceview/gtksourcestyle.h>
#include <gtksourceview/gtksourcestylescheme.h>
#include <gtksourceview/gtksourcestyleschememanager.h>
#include <gtksourceview/gtksourcetag.h>
#include <gtksourceview/gtksourceundomanager.h>
#include <gtksourceview/gtksourceutils.h>
#include <gtksourceview/gtksourceview.h>
#include <gtksourceview/gtksource-enumtypes.h>
#include <gtksourceview/gtksourceautocleanups.h>

#undef GTK_SOURCE_H_INSIDE
