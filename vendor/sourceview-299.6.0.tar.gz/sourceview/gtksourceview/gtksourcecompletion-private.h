/* SPDX-FileCopyrightText: 2009 - Jesse van den Kieboom <jessevdk@gnome.org>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <gtk/gtk.h>
#include <gtksourceview/gtksourcetypes.h>

G_BEGIN_DECLS

G_GNUC_INTERNAL
GtkSourceCompletion *gtk_source_completion_new (GtkSourceView *source_view);

G_END_DECLS
