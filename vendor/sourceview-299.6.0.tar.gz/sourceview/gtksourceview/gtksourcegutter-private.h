/* SPDX-FileCopyrightText: 2009 - Jesse van den Kieboom
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <gtk/gtk.h>
#include "gtksourcetypes.h"

G_BEGIN_DECLS

G_GNUC_INTERNAL
GtkSourceGutter *	_gtk_source_gutter_new		(GtkSourceView     *view,
							 GtkTextWindowType  type);

G_GNUC_INTERNAL
void			_gtk_source_gutter_draw		(GtkSourceGutter *gutter,
							 GtkSourceView   *view,
							 cairo_t         *cr);


G_END_DECLS
