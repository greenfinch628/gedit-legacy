/* SPDX-FileCopyrightText: 2010 - Jesse van den Kieboom
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <gtk/gtk.h>
#include "gtksourcetypes.h"
#include "gtksourcegutterrenderertext.h"

G_BEGIN_DECLS

#define GTK_SOURCE_TYPE_GUTTER_RENDERER_LINES		(gtk_source_gutter_renderer_lines_get_type ())
#define GTK_SOURCE_GUTTER_RENDERER_LINES(obj)		(G_TYPE_CHECK_INSTANCE_CAST ((obj), GTK_SOURCE_TYPE_GUTTER_RENDERER_LINES, GtkSourceGutterRendererLines))
#define GTK_SOURCE_GUTTER_RENDERER_LINES_CONST(obj)	(G_TYPE_CHECK_INSTANCE_CAST ((obj), GTK_SOURCE_TYPE_GUTTER_RENDERER_LINES, GtkSourceGutterRendererLines const))
#define GTK_SOURCE_GUTTER_RENDERER_LINES_CLASS(klass)	(G_TYPE_CHECK_CLASS_CAST ((klass), GTK_SOURCE_TYPE_GUTTER_RENDERER_LINES, GtkSourceGutterRendererLinesClass))
#define GTK_SOURCE_IS_GUTTER_RENDERER_LINES(obj)		(G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTK_SOURCE_TYPE_GUTTER_RENDERER_LINES))
#define GTK_SOURCE_IS_GUTTER_RENDERER_LINES_CLASS(klass)	(G_TYPE_CHECK_CLASS_TYPE ((klass), GTK_SOURCE_TYPE_GUTTER_RENDERER_LINES))
#define GTK_SOURCE_GUTTER_RENDERER_LINES_GET_CLASS(obj)	(G_TYPE_INSTANCE_GET_CLASS ((obj), GTK_SOURCE_TYPE_GUTTER_RENDERER_LINES, GtkSourceGutterRendererLinesClass))

typedef struct _GtkSourceGutterRendererLines         GtkSourceGutterRendererLines;
typedef struct _GtkSourceGutterRendererLinesClass    GtkSourceGutterRendererLinesClass;
typedef struct _GtkSourceGutterRendererLinesPrivate  GtkSourceGutterRendererLinesPrivate;

struct _GtkSourceGutterRendererLines
{
	/*< private >*/
	GtkSourceGutterRendererText parent;

	GtkSourceGutterRendererLinesPrivate *priv;

	/*< public >*/
};

struct _GtkSourceGutterRendererLinesClass
{
	/*< private >*/
	GtkSourceGutterRendererTextClass parent_class;

	/*< public >*/
};

G_GNUC_INTERNAL
GType gtk_source_gutter_renderer_lines_get_type (void) G_GNUC_CONST;

G_GNUC_INTERNAL
GtkSourceGutterRenderer *gtk_source_gutter_renderer_lines_new (void);

G_END_DECLS
