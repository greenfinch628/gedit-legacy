/* SPDX-FileCopyrightText: 2015 - Université Catholique de Louvain
 * SPDX-License-Identifier: LGPL-2.1-or-later
 *
 * Author: Sébastien Wilmet
 */

#pragma once

#if !defined (GTK_SOURCE_H_INSIDE) && !defined (GTK_SOURCE_COMPILATION)
#error "Only <gtksourceview/gtksource.h> can be included directly."
#endif

#include <gtk/gtk.h>
#include <gtksourceview/gtksourcetypes.h>

G_BEGIN_DECLS

#define GTK_SOURCE_TYPE_TAG (gtk_source_tag_get_type ())

G_MODULE_EXPORT
G_DECLARE_DERIVABLE_TYPE (GtkSourceTag, gtk_source_tag,
			  GTK_SOURCE, TAG,
			  GtkTextTag)

struct _GtkSourceTagClass
{
	GtkTextTagClass parent_class;

	gpointer padding[1];
};

G_MODULE_EXPORT
GtkTextTag *	gtk_source_tag_new		(const gchar *name);

G_END_DECLS
