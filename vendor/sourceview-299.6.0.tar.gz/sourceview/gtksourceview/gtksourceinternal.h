/* SPDX-FileCopyrightText: 2012-2025 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <glib.h>

G_BEGIN_DECLS

#ifdef _MSC_VER
/* For Visual Studio, we need to export the symbols used by the unit tests */
#define GTK_SOURCE_INTERNAL __declspec(dllexport)
#else
#define GTK_SOURCE_INTERNAL G_GNUC_INTERNAL
#endif

G_END_DECLS
