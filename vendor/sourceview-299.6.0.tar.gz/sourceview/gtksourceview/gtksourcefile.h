/* SPDX-FileCopyrightText: 2014-2025 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#if !defined (GTK_SOURCE_H_INSIDE) && !defined (GTK_SOURCE_COMPILATION)
#error "Only <gtksourceview/gtksource.h> can be included directly."
#endif

#include <gtk/gtk.h>
#include <gtksourceview/gtksourceencoding.h>

G_BEGIN_DECLS

#define GTK_SOURCE_TYPE_FILE             (gtk_source_file_get_type ())
#define GTK_SOURCE_FILE(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), GTK_SOURCE_TYPE_FILE, GtkSourceFile))
#define GTK_SOURCE_FILE_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), GTK_SOURCE_TYPE_FILE, GtkSourceFileClass))
#define GTK_SOURCE_IS_FILE(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTK_SOURCE_TYPE_FILE))
#define GTK_SOURCE_IS_FILE_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), GTK_SOURCE_TYPE_FILE))
#define GTK_SOURCE_FILE_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), GTK_SOURCE_TYPE_FILE, GtkSourceFileClass))

typedef struct _GtkSourceFile         GtkSourceFile;
typedef struct _GtkSourceFileClass    GtkSourceFileClass;
typedef struct _GtkSourceFilePrivate  GtkSourceFilePrivate;

/**
 * GtkSourceNewlineType:
 * @GTK_SOURCE_NEWLINE_TYPE_LF: Line feed, used on UNIX.
 * @GTK_SOURCE_NEWLINE_TYPE_CR: Carriage return, used on macOS.
 * @GTK_SOURCE_NEWLINE_TYPE_CR_LF: Carriage return followed by a line feed, used
 *   on Windows.
 *
 * Since: 3.14
 */
typedef enum
{
	GTK_SOURCE_NEWLINE_TYPE_LF,
	GTK_SOURCE_NEWLINE_TYPE_CR,
	GTK_SOURCE_NEWLINE_TYPE_CR_LF
} GtkSourceNewlineType;

/**
 * GTK_SOURCE_NEWLINE_TYPE_DEFAULT:
 *
 * The default newline type on the current OS.
 *
 * Since: 3.14
 */
/* For GTK-Doc: have the LF first, to not have something weird in the docs. */
#ifndef G_OS_WIN32
#define GTK_SOURCE_NEWLINE_TYPE_DEFAULT GTK_SOURCE_NEWLINE_TYPE_LF
#else
#define GTK_SOURCE_NEWLINE_TYPE_DEFAULT GTK_SOURCE_NEWLINE_TYPE_CR_LF
#endif

/**
 * GtkSourceCompressionType:
 * @GTK_SOURCE_COMPRESSION_TYPE_NONE: Plain text.
 * @GTK_SOURCE_COMPRESSION_TYPE_GZIP: Gzip compression.
 *
 * Since: 3.14
 */
typedef enum
{
	GTK_SOURCE_COMPRESSION_TYPE_NONE,
	GTK_SOURCE_COMPRESSION_TYPE_GZIP
} GtkSourceCompressionType;

/**
 * GtkSourceMountOperationFactory:
 * @file: a #GtkSourceFile.
 * @userdata: user data.
 *
 * Type definition for a function that will be called to create a
 * #GMountOperation. This is useful for creating a #GtkMountOperation.
 *
 * Since: 3.14
 */
typedef GMountOperation *(*GtkSourceMountOperationFactory) (GtkSourceFile *file,
							    gpointer       userdata);

struct _GtkSourceFile
{
	GObject parent;

	GtkSourceFilePrivate *priv;
};

struct _GtkSourceFileClass
{
	GObjectClass parent_class;

	gpointer padding[1];
};

G_MODULE_EXPORT
GType		gtk_source_file_get_type			(void) G_GNUC_CONST;

G_MODULE_EXPORT
GtkSourceFile *	gtk_source_file_new				(void);

G_MODULE_EXPORT
GFile *		gtk_source_file_get_location			(GtkSourceFile *file);

G_MODULE_EXPORT
void		gtk_source_file_set_location			(GtkSourceFile *file,
								 GFile         *location);

G_MODULE_EXPORT
const GtkSourceEncoding *
		gtk_source_file_get_encoding			(GtkSourceFile *file);

G_MODULE_EXPORT
GtkSourceNewlineType
		gtk_source_file_get_newline_type		(GtkSourceFile *file);

G_MODULE_EXPORT
GtkSourceCompressionType
		gtk_source_file_get_compression_type		(GtkSourceFile *file);

G_MODULE_EXPORT
void		gtk_source_file_set_mount_operation_factory	(GtkSourceFile                  *file,
								 GtkSourceMountOperationFactory  callback,
								 gpointer                        user_data,
								 GDestroyNotify                  notify);

G_MODULE_EXPORT
void		gtk_source_file_check_file_on_disk		(GtkSourceFile *file);

G_MODULE_EXPORT
gboolean	gtk_source_file_is_local			(GtkSourceFile *file);

G_MODULE_EXPORT
gboolean	gtk_source_file_is_externally_modified		(GtkSourceFile *file);

G_MODULE_EXPORT
gboolean	gtk_source_file_is_deleted			(GtkSourceFile *file);

G_MODULE_EXPORT
gboolean	gtk_source_file_is_readonly			(GtkSourceFile *file);

G_GNUC_INTERNAL
void		_gtk_source_file_set_encoding			(GtkSourceFile           *file,
								 const GtkSourceEncoding *encoding);

G_GNUC_INTERNAL
void		_gtk_source_file_set_newline_type		(GtkSourceFile        *file,
								 GtkSourceNewlineType  newline_type);

G_GNUC_INTERNAL
void		_gtk_source_file_set_compression_type		(GtkSourceFile            *file,
								 GtkSourceCompressionType  compression_type);

G_GNUC_INTERNAL
GMountOperation *_gtk_source_file_create_mount_operation	(GtkSourceFile *file);

/* GTimeVal is deprecated, but we don't want to produce compilation warnings for
 * other modules that #include the GtkSourceView headers.
 * FIXME: GTimeVal is deprecated.
 */
G_GNUC_BEGIN_IGNORE_DEPRECATIONS
G_GNUC_INTERNAL
gboolean	_gtk_source_file_get_modification_time		(GtkSourceFile *file,
								 GTimeVal      *modification_time);

G_GNUC_INTERNAL
void		_gtk_source_file_set_modification_time		(GtkSourceFile *file,
								 GTimeVal       modification_time);
G_GNUC_END_IGNORE_DEPRECATIONS

G_GNUC_INTERNAL
void		_gtk_source_file_set_externally_modified	(GtkSourceFile *file,
								 gboolean       externally_modified);

G_GNUC_INTERNAL
void		_gtk_source_file_set_deleted			(GtkSourceFile *file,
								 gboolean       deleted);

G_GNUC_INTERNAL
void		_gtk_source_file_set_readonly			(GtkSourceFile *file,
								 gboolean       readonly);

G_END_DECLS
