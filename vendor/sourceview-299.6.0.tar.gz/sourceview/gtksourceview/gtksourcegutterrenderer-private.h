/* SPDX-FileCopyrightText: 2010 - Krzesimir Nowak
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <gtk/gtk.h>
#include "gtksourcetypes.h"

G_BEGIN_DECLS

G_GNUC_INTERNAL
void _gtk_source_gutter_renderer_set_view         (GtkSourceGutterRenderer *renderer,
                                                   GtkTextView             *view,
                                                   GtkTextWindowType        window_type);

G_END_DECLS
