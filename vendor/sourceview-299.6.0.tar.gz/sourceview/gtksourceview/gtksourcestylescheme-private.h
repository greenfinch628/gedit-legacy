/* SPDX-FileCopyrightText: 2023 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include "gtksourcestyleschemecss.h"

G_BEGIN_DECLS

G_GNUC_INTERNAL
GtkSourceStyleSchemeCss *
		_gtk_source_style_scheme_get_style_scheme_css	(GtkSourceStyleScheme *scheme);

G_END_DECLS
