/* SPDX-FileCopyrightText: 1998, 1999 Alex Roberts, Evan Lawrence
 * SPDX-FileCopyrightText: 2000, 2001 Chema Celorio, Paolo Maggi
 * SPDX-FileCopyrightText: 2002, 2003 Paolo Maggi
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <glib-object.h>

G_BEGIN_DECLS

#define GTK_SOURCE_TYPE_UNDO_MANAGER_DEFAULT		(gtk_source_undo_manager_default_get_type ())
#define GTK_SOURCE_UNDO_MANAGER_DEFAULT(obj)		(G_TYPE_CHECK_INSTANCE_CAST((obj), GTK_SOURCE_TYPE_UNDO_MANAGER_DEFAULT, GtkSourceUndoManagerDefault))
#define GTK_SOURCE_UNDO_MANAGER_DEFAULT_CLASS(klass)	(G_TYPE_CHECK_CLASS_CAST((klass), GTK_SOURCE_TYPE_UNDO_MANAGER_DEFAULT, GtkSourceUndoManagerDefaultClass))
#define GTK_SOURCE_IS_UNDO_MANAGER_DEFAULT(obj)		(G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTK_SOURCE_TYPE_UNDO_MANAGER_DEFAULT))
#define GTK_SOURCE_IS_UNDO_MANAGER_DEFAULT_CLASS(klass)	(G_TYPE_CHECK_CLASS_TYPE ((klass), GTK_SOURCE_TYPE_UNDO_MANAGER_DEFAULT))
#define GTK_SOURCE_UNDO_MANAGER_DEFAULT_GET_CLASS(obj)	(G_TYPE_INSTANCE_GET_CLASS ((obj), GTK_SOURCE_TYPE_UNDO_MANAGER_DEFAULT, GtkSourceUndoManagerDefaultClass))

typedef struct _GtkSourceUndoManagerDefault         GtkSourceUndoManagerDefault;
typedef struct _GtkSourceUndoManagerDefaultClass    GtkSourceUndoManagerDefaultClass;
typedef struct _GtkSourceUndoManagerDefaultPrivate  GtkSourceUndoManagerDefaultPrivate;

struct _GtkSourceUndoManagerDefault
{
	GObject parent;

	GtkSourceUndoManagerDefaultPrivate *priv;
};

struct _GtkSourceUndoManagerDefaultClass
{
	GObjectClass parent_class;
};

G_GNUC_INTERNAL
GType gtk_source_undo_manager_default_get_type (void) G_GNUC_CONST;

G_GNUC_INTERNAL
void gtk_source_undo_manager_default_set_max_undo_levels (GtkSourceUndoManagerDefault *manager,
                                                          gint                         max_undo_levels);

G_END_DECLS
