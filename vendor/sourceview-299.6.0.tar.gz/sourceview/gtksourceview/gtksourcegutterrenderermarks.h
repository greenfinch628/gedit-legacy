/* SPDX-FileCopyrightText: 2010 - Jesse van den Kieboom
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <gtk/gtk.h>
#include "gtksourcetypes.h"
#include "gtksourcegutterrendererpixbuf.h"

G_BEGIN_DECLS

#define GTK_SOURCE_TYPE_GUTTER_RENDERER_MARKS		(gtk_source_gutter_renderer_marks_get_type ())
#define GTK_SOURCE_GUTTER_RENDERER_MARKS(obj)		(G_TYPE_CHECK_INSTANCE_CAST ((obj), GTK_SOURCE_TYPE_GUTTER_RENDERER_MARKS, GtkSourceGutterRendererMarks))
#define GTK_SOURCE_GUTTER_RENDERER_MARKS_CONST(obj)	(G_TYPE_CHECK_INSTANCE_CAST ((obj), GTK_SOURCE_TYPE_GUTTER_RENDERER_MARKS, GtkSourceGutterRendererMarks const))
#define GTK_SOURCE_GUTTER_RENDERER_MARKS_CLASS(klass)	(G_TYPE_CHECK_CLASS_CAST ((klass), GTK_SOURCE_TYPE_GUTTER_RENDERER_MARKS, GtkSourceGutterRendererMarksClass))
#define GTK_SOURCE_IS_GUTTER_RENDERER_MARKS(obj)	(G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTK_SOURCE_TYPE_GUTTER_RENDERER_MARKS))
#define GTK_SOURCE_IS_GUTTER_RENDERER_MARKS_CLASS(klass)(G_TYPE_CHECK_CLASS_TYPE ((klass), GTK_SOURCE_TYPE_GUTTER_RENDERER_MARKS))
#define GTK_SOURCE_GUTTER_RENDERER_MARKS_GET_CLASS(obj)	(G_TYPE_INSTANCE_GET_CLASS ((obj), GTK_SOURCE_TYPE_GUTTER_RENDERER_MARKS, GtkSourceGutterRendererMarksClass))

typedef struct _GtkSourceGutterRendererMarks       GtkSourceGutterRendererMarks;
typedef struct _GtkSourceGutterRendererMarksClass  GtkSourceGutterRendererMarksClass;

struct _GtkSourceGutterRendererMarks
{
	GtkSourceGutterRendererPixbuf parent;
};

struct _GtkSourceGutterRendererMarksClass
{
	GtkSourceGutterRendererPixbufClass parent_class;
};

G_GNUC_INTERNAL
GType gtk_source_gutter_renderer_marks_get_type (void) G_GNUC_CONST;

G_GNUC_INTERNAL
GtkSourceGutterRenderer *gtk_source_gutter_renderer_marks_new (void);

G_END_DECLS
