/* SPDX-FileCopyrightText: 2016 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <gtk/gtk.h>
#include "gtksourcetypes.h"
#include "gtksourceinternal.h"

G_BEGIN_DECLS

GTK_SOURCE_INTERNAL
void			_gtk_source_space_drawer_update_color		(GtkSourceSpaceDrawer *drawer,
									 GtkSourceView        *view);

GTK_SOURCE_INTERNAL
void			_gtk_source_space_drawer_draw			(GtkSourceSpaceDrawer *drawer,
									 GtkSourceView        *view,
									 cairo_t              *cr);

G_END_DECLS
