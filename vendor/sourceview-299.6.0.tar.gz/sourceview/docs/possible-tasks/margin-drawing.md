Margin drawing
==============

Drawing the right-margin is currently done by the GtkSourceView class.

The GtkSourceView class is quite large (the implementation at least).

**Status: not started**

GtkSourceRightMargin internal class
-----------------------------------

Possibility to do the "Extract Class" refactoring.

Extract the GtkSourceRightMargin class from GtkSourceView.

GtkSourceRightMargin would be an internal class, not exposed in the API.

GtkSourceMarginDrawing API
--------------------------

Another possibility, while working in that area of the code, is to create a more
flexible GObject class.

The GtkSourceMarginDrawing class would take a GtkSourceView widget as an
instance variable (weak ref).

GtkSourceMarginDrawing could be instantiated several times for the same
GtkSourceView widget, to draw several margins (left/right, or for soft/hard
limits).

Expose that class in the API, deprecating/removing the previous API in the
GtkSourceView class.
