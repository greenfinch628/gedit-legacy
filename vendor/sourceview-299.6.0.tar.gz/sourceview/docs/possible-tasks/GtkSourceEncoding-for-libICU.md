GtkSourceEncoding for libICU
============================

Add a type field?
-----------------

Two types of GtkSourceEncoding instances: for iconv, for libICU (have an enum
with these two values).

Modify the API to take a type parameter for some functions.

Since GtkSourceEncoding is a boxed type, it's more difficult to have a good OOP
class design.
