/* SPDX-FileCopyrightText: 2025 - Sébastien Wilmet
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#ifndef TEPL_CODE_COMMENT_H
#define TEPL_CODE_COMMENT_H

#if !defined (TEPL_H_INSIDE) && !defined (TEPL_COMPILATION)
#error "Only <tepl/tepl.h> can be included directly."
#endif

#include <tepl/code-comment/tepl-code-comment-view.h>

#endif /* TEPL_CODE_COMMENT_H */
