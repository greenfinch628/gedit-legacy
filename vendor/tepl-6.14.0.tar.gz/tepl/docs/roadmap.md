libgedit-tepl roadmap
=====================

This page contains the plans for major code changes we hope to get done in the
future.

File loading and saving plans
-----------------------------

- Improve the implementation in libgedit-gtksourceview instead of duplicating
  the API in libgedit-tepl (Encoding, File, FileLoader and FileSaver classes).
  Once done, remove the relevant classes from libgedit-tepl.

- In libgedit-tepl: provide the high-level API with TeplInfoBars etc.

Search and replace UI
---------------------

- Status: **todo**

File printing UI
----------------

- Status: **todo**

File browser widget
-------------------

- Status: **todo**

To be integrated in a side panel.
