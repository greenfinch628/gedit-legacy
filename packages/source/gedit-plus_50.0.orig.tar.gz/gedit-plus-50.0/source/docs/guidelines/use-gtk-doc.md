Gedit Development Guidelines - Use GTK-Doc
==========================================

The gedit projects use GTK-Doc, not gi-docgen.

With GTK-Doc there is a table of contents. We can structure the documentation,
regroup related classes together.

We can list the classes in a logical manner, for example by following the
containment hierarchy:
1. App
2. Window
3. Tab
4. TextView
5. TextBuffer

We can list functions in a logical manner, for example in the order that they
need to be called:
1. The constructors.
2. Functions to configure the object.
3. Functions to launch the operation.
4. Functions to retrieve the results.

A whole class is documented on a single HTML page, which makes browsing easier.
With gi-docgen it's one page per symbol, so we need to open many tabs in the API
browser (less convenient).

GTK-Doc has indexes that list symbols per version. So once a new version is
released, a developer can easily discover what's new. Something that gi-docgen
currently lacks.
