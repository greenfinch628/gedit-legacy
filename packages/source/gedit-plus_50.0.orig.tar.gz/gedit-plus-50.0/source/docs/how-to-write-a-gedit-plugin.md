How to write a gedit plugin
===========================

The [gedit-development-getting-started.md](gedit-development-getting-started.md)
documentation is a good start.

Programming language for a gedit plugin
---------------------------------------

All official plugins are implemented in **C**, so there are a lot of examples.

Nowadays **Rust** would be recommended, but has not been tried yet for a gedit
plugin. It is not sure that it's actually possible at the time of writing.

**C++** should be possible too, but has not been tried yet for gedit.

There was a plugin implemented in **Vala** ("Find in Files", part of
gedit-plugins, but it has been removed), so that's another possibility.

For the gedit and gedit-plugins repositories we prefer to deal with a single
programming language (C), that way we avoid the complexity of managing a
multi-language project.

For third-party plugins, you thus have the choice between C, C++, Vala and maybe
Rust. If you plan to propose your plugin for inclusion in gedit itself, choose
the C language.

### What about Python?

See
[this blog post](https://gedit-text-editor.org/blog/2025-04-30-no-more-pythons-in-gedit.html).

API reference
-------------

Build gedit with `-D gtk_doc=true`, you can then browse the API reference in the
[Devhelp](https://github.com/gdev-technology/devhelp) application.

To know how to write a plugin, refer to the
[libpeas](https://wiki.gnome.org/Projects/Libpeas) documentation as well.

Tool to generate a new plugin in C
----------------------------------

In the `tools/` directory there is a script to generate the boilerplate C code.

More documentation and tips
---------------------------

More documentation, for example a tutorial, would be useful. In the meantime,
the recommended thing to do is to see how core gedit plugins are implemented.

### Unofficial documentation and tutorials (may be outdated)

- [Writing plugins in Vala](https://wiki.gnome.org/Projects/Vala/Gedit3PluginSample) (maybe outdated)
