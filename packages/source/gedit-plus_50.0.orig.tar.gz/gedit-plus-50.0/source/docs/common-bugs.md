Common gedit bugs
=================

This page documents common bugs in gedit. If you find your problem in this page,
_please do not report a new bug for it_.

Problem with very long lines
----------------------------

Very long lines (e.g. a wrapped line that takes the whole screen) are not well
supported by gedit, there can be performance problems or freezes.

[GitLab issue](https://gitlab.gnome.org/World/gedit/gedit/-/issues/513).

Hyphen/dash inserted for text wrapping
--------------------------------------

It should be disabled in a text editor like gedit, the hyphen is not part of
the content.

[GitLab issue](https://gitlab.gnome.org/World/gedit/gedit/-/issues/365).

Fixed
-----

### Problem with very large files

Fixed in >= 49.

gedit now refuses to load very large files. The limit is configurable with the
GSettings key: `org.gnome.gedit.preferences.editor max-file-size`

- [GitLab issue](https://gitlab.gnome.org/World/gedit/gedit/-/issues/11) (fixed)
- [GitLab issue for further improvements](https://gitlab.gnome.org/World/gedit/gedit/-/issues/635)
  (still to do)

### View does not scroll to the end of the text in some cases (text cut off)

Fixed in 40.2, 41.1, 42.2 and >= 43.

[GitLab issue](https://gitlab.gnome.org/World/gedit/gedit/-/issues/42).
