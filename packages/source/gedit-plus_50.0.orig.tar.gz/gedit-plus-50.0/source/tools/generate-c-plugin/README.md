gedit - generate-c-plugin tool
==============================

A tool to generate the boilerplate C code for a new plugin.

Open `generate.sh` and set up the configuration, then run the script.

Running the script will copy and adapt the templates.

Dependencies
------------

Some [gdev-c-utils](https://gitlab.gnome.org/swilmet/gdev-c-utils) ("gcu" for
short) programs are required.

What's left to do
-----------------

Once the `*.c` and `*.h` files are generated, what's missing is:
- The `*.plugin` (or `*.plugin.desktop.in`) file.
- The build instructions (usually with Meson).

The three extension points are implemented (GeditAppActivatable,
GeditWindowActivatable and GeditViewActivatable), but you should of course keep
only what is necessary.
