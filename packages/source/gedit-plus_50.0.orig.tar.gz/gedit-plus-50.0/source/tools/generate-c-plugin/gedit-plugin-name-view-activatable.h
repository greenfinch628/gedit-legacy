#pragma once

#include <libpeas/peas.h>

G_BEGIN_DECLS

#define GEDIT_TYPE_PLUGIN_NAME_VIEW_ACTIVATABLE             (gedit_plugin_name_view_activatable_get_type ())
#define GEDIT_PLUGIN_NAME_VIEW_ACTIVATABLE(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), GEDIT_TYPE_PLUGIN_NAME_VIEW_ACTIVATABLE, GeditPluginNameViewActivatable))
#define GEDIT_PLUGIN_NAME_VIEW_ACTIVATABLE_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), GEDIT_TYPE_PLUGIN_NAME_VIEW_ACTIVATABLE, GeditPluginNameViewActivatableClass))
#define GEDIT_IS_PLUGIN_NAME_VIEW_ACTIVATABLE(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GEDIT_TYPE_PLUGIN_NAME_VIEW_ACTIVATABLE))
#define GEDIT_IS_PLUGIN_NAME_VIEW_ACTIVATABLE_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), GEDIT_TYPE_PLUGIN_NAME_VIEW_ACTIVATABLE))
#define GEDIT_PLUGIN_NAME_VIEW_ACTIVATABLE_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), GEDIT_TYPE_PLUGIN_NAME_VIEW_ACTIVATABLE, GeditPluginNameViewActivatableClass))

typedef struct _GeditPluginNameViewActivatable         GeditPluginNameViewActivatable;
typedef struct _GeditPluginNameViewActivatableClass    GeditPluginNameViewActivatableClass;
typedef struct _GeditPluginNameViewActivatablePrivate  GeditPluginNameViewActivatablePrivate;

struct _GeditPluginNameViewActivatable
{
	GObject parent;

	GeditPluginNameViewActivatablePrivate *priv;
};

struct _GeditPluginNameViewActivatableClass
{
	GObjectClass parent_class;
};

GType	gedit_plugin_name_view_activatable_get_type	(void);

void	gedit_plugin_name_view_activatable_register	(PeasObjectModule *module);

G_END_DECLS
