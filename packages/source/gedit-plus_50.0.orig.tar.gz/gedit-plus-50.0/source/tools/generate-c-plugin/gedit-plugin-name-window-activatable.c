#include "gedit-plugin-name-window-activatable.h"
#include <gedit/gedit-window.h>
#include <gedit/gedit-window-activatable.h>

struct _GeditPluginNameWindowActivatablePrivate
{
	GeditWindow *window;
};

enum
{
	PROP_0,
	PROP_WINDOW
};

static void gedit_window_activatable_iface_init (GeditWindowActivatableInterface *iface);

G_DEFINE_DYNAMIC_TYPE_EXTENDED (GeditPluginNameWindowActivatable,
				gedit_plugin_name_window_activatable,
				G_TYPE_OBJECT,
				0,
				G_ADD_PRIVATE_DYNAMIC (GeditPluginNameWindowActivatable)
				G_IMPLEMENT_INTERFACE_DYNAMIC (GEDIT_TYPE_WINDOW_ACTIVATABLE,
							       gedit_window_activatable_iface_init))

static void
gedit_plugin_name_window_activatable_get_property (GObject    *object,
						   guint       prop_id,
						   GValue     *value,
						   GParamSpec *pspec)
{
	GeditPluginNameWindowActivatable *activatable = GEDIT_PLUGIN_NAME_WINDOW_ACTIVATABLE (object);

	switch (prop_id)
	{
		case PROP_WINDOW:
			g_value_set_object (value, activatable->priv->window);
			break;

		default:
			G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
			break;
	}
}

static void
gedit_plugin_name_window_activatable_set_property (GObject      *object,
						   guint         prop_id,
						   const GValue *value,
						   GParamSpec   *pspec)
{
	GeditPluginNameWindowActivatable *activatable = GEDIT_PLUGIN_NAME_WINDOW_ACTIVATABLE (object);

	switch (prop_id)
	{
		case PROP_WINDOW:
			g_assert (activatable->priv->window == NULL);
			activatable->priv->window = GEDIT_WINDOW (g_value_dup_object (value));
			break;

		default:
			G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
			break;
	}
}

static void
gedit_plugin_name_window_activatable_dispose (GObject *object)
{
	GeditPluginNameWindowActivatable *activatable = GEDIT_PLUGIN_NAME_WINDOW_ACTIVATABLE (object);

	g_clear_object (&activatable->priv->window);

	G_OBJECT_CLASS (gedit_plugin_name_window_activatable_parent_class)->dispose (object);
}

static void
gedit_plugin_name_window_activatable_finalize (GObject *object)
{

	G_OBJECT_CLASS (gedit_plugin_name_window_activatable_parent_class)->finalize (object);
}

static void
gedit_plugin_name_window_activatable_class_init (GeditPluginNameWindowActivatableClass *klass)
{
	GObjectClass *object_class = G_OBJECT_CLASS (klass);

	object_class->get_property = gedit_plugin_name_window_activatable_get_property;
	object_class->set_property = gedit_plugin_name_window_activatable_set_property;
	object_class->dispose = gedit_plugin_name_window_activatable_dispose;
	object_class->finalize = gedit_plugin_name_window_activatable_finalize;

	g_object_class_override_property (object_class, PROP_WINDOW, "window");
}

static void
gedit_plugin_name_window_activatable_class_finalize (GeditPluginNameWindowActivatableClass *klass)
{
}

static void
gedit_plugin_name_window_activatable_init (GeditPluginNameWindowActivatable *activatable)
{
	activatable->priv = gedit_plugin_name_window_activatable_get_instance_private (activatable);
}

static void
gedit_plugin_name_window_activatable_activate (GeditWindowActivatable *activatable)
{
	//GeditPluginNameWindowActivatable *self = GEDIT_PLUGIN_NAME_WINDOW_ACTIVATABLE (activatable);

	g_message ("%s()", G_STRFUNC);
}

static void
gedit_plugin_name_window_activatable_deactivate (GeditWindowActivatable *activatable)
{
	//GeditPluginNameWindowActivatable *self = GEDIT_PLUGIN_NAME_WINDOW_ACTIVATABLE (activatable);

	g_message ("%s()", G_STRFUNC);
}

static void
gedit_window_activatable_iface_init (GeditWindowActivatableInterface *iface)
{
	iface->activate = gedit_plugin_name_window_activatable_activate;
	iface->deactivate = gedit_plugin_name_window_activatable_deactivate;
}

void
gedit_plugin_name_window_activatable_register (PeasObjectModule *module)
{
	gedit_plugin_name_window_activatable_register_type (G_TYPE_MODULE (module));

	peas_object_module_register_extension_type (module,
						    GEDIT_TYPE_WINDOW_ACTIVATABLE,
						    GEDIT_TYPE_PLUGIN_NAME_WINDOW_ACTIVATABLE);
}
