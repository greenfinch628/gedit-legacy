#pragma once

#include <libpeas/peas.h>

G_BEGIN_DECLS

#define GEDIT_TYPE_PLUGIN_NAME_APP_ACTIVATABLE             (gedit_plugin_name_app_activatable_get_type ())
#define GEDIT_PLUGIN_NAME_APP_ACTIVATABLE(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), GEDIT_TYPE_PLUGIN_NAME_APP_ACTIVATABLE, GeditPluginNameAppActivatable))
#define GEDIT_PLUGIN_NAME_APP_ACTIVATABLE_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), GEDIT_TYPE_PLUGIN_NAME_APP_ACTIVATABLE, GeditPluginNameAppActivatableClass))
#define GEDIT_IS_PLUGIN_NAME_APP_ACTIVATABLE(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GEDIT_TYPE_PLUGIN_NAME_APP_ACTIVATABLE))
#define GEDIT_IS_PLUGIN_NAME_APP_ACTIVATABLE_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), GEDIT_TYPE_PLUGIN_NAME_APP_ACTIVATABLE))
#define GEDIT_PLUGIN_NAME_APP_ACTIVATABLE_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), GEDIT_TYPE_PLUGIN_NAME_APP_ACTIVATABLE, GeditPluginNameAppActivatableClass))

typedef struct _GeditPluginNameAppActivatable         GeditPluginNameAppActivatable;
typedef struct _GeditPluginNameAppActivatableClass    GeditPluginNameAppActivatableClass;
typedef struct _GeditPluginNameAppActivatablePrivate  GeditPluginNameAppActivatablePrivate;

struct _GeditPluginNameAppActivatable
{
	GObject parent;

	GeditPluginNameAppActivatablePrivate *priv;
};

struct _GeditPluginNameAppActivatableClass
{
	GObjectClass parent_class;
};

GType	gedit_plugin_name_app_activatable_get_type	(void);

void	gedit_plugin_name_app_activatable_register	(PeasObjectModule *module);

G_END_DECLS
