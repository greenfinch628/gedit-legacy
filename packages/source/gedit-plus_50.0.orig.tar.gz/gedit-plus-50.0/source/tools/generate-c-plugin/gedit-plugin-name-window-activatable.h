#pragma once

#include <libpeas/peas.h>

G_BEGIN_DECLS

#define GEDIT_TYPE_PLUGIN_NAME_WINDOW_ACTIVATABLE             (gedit_plugin_name_window_activatable_get_type ())
#define GEDIT_PLUGIN_NAME_WINDOW_ACTIVATABLE(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), GEDIT_TYPE_PLUGIN_NAME_WINDOW_ACTIVATABLE, GeditPluginNameWindowActivatable))
#define GEDIT_PLUGIN_NAME_WINDOW_ACTIVATABLE_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), GEDIT_TYPE_PLUGIN_NAME_WINDOW_ACTIVATABLE, GeditPluginNameWindowActivatableClass))
#define GEDIT_IS_PLUGIN_NAME_WINDOW_ACTIVATABLE(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GEDIT_TYPE_PLUGIN_NAME_WINDOW_ACTIVATABLE))
#define GEDIT_IS_PLUGIN_NAME_WINDOW_ACTIVATABLE_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), GEDIT_TYPE_PLUGIN_NAME_WINDOW_ACTIVATABLE))
#define GEDIT_PLUGIN_NAME_WINDOW_ACTIVATABLE_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), GEDIT_TYPE_PLUGIN_NAME_WINDOW_ACTIVATABLE, GeditPluginNameWindowActivatableClass))

typedef struct _GeditPluginNameWindowActivatable         GeditPluginNameWindowActivatable;
typedef struct _GeditPluginNameWindowActivatableClass    GeditPluginNameWindowActivatableClass;
typedef struct _GeditPluginNameWindowActivatablePrivate  GeditPluginNameWindowActivatablePrivate;

struct _GeditPluginNameWindowActivatable
{
	GObject parent;

	GeditPluginNameWindowActivatablePrivate *priv;
};

struct _GeditPluginNameWindowActivatableClass
{
	GObjectClass parent_class;
};

GType	gedit_plugin_name_window_activatable_get_type	(void);

void	gedit_plugin_name_window_activatable_register	(PeasObjectModule *module);

G_END_DECLS
