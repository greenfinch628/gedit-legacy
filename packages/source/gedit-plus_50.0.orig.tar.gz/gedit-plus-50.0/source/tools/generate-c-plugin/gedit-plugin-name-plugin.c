#include "gedit-plugin-name-plugin.h"
#include "gedit-plugin-name-app-activatable.h"
#include "gedit-plugin-name-window-activatable.h"
#include "gedit-plugin-name-view-activatable.h"

G_MODULE_EXPORT void
peas_register_types (PeasObjectModule *module)
{
	gedit_plugin_name_app_activatable_register (module);
	gedit_plugin_name_window_activatable_register (module);
	gedit_plugin_name_view_activatable_register (module);
}
