/* SPDX-FileCopyrightText: 2025 - Sébastien Wilmet
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#include "gedit-tab.h"

G_BEGIN_DECLS

G_GNUC_INTERNAL
gchar *		_gedit_tab_utils_get_tooltip		(GeditTab *tab);

G_GNUC_INTERNAL
const gchar *	_gedit_tab_utils_get_icon_name		(GeditTab *tab);

G_END_DECLS
