#include "config.h"
#include "gedit-drafts.h"
#include "gedit-preferences-dialog.h"
#include "gedit-commands-private.h"
#include "gedit-close-confirmation-dialog.h"
#include "gedit-document-private.h"
#include "gedit-tab-private.h"
#include "gedit-dirs.h"
#include "gedit-factory.h"
#include <tepl/tepl.h>
#include <glib/gstdio.h>

static GList *all_tabs (GeditWindow *w)
{
 GList *docs = gedit_window_get_documents (w);
 for (GList *l = docs; l; l = l->next) l->data = gedit_tab_get_from_document (l->data);
 return docs;
}
static GtkToggleButton *find_draft_toggle (GtkWidget *widget)
{
 if (GTK_IS_CHECK_BUTTON (widget) &&
     g_strcmp0 (gtk_button_get_label (GTK_BUTTON (widget)),
                "Preserve _untitled documents when closing") == 0)
  return GTK_TOGGLE_BUTTON (widget);
 if (GTK_IS_CONTAINER (widget))
 {
  GList *children = gtk_container_get_children (GTK_CONTAINER (widget));
  for (GList *l = children; l; l = l->next)
  {
   GtkToggleButton *button = find_draft_toggle (l->data);
   if (button) { g_list_free (children); return button; }
  }
  g_list_free (children);
 }
 return NULL;
}
static void drain (void) { while (g_main_context_iteration (NULL, FALSE)); }
static GeditTab *add (GeditWindow *w, const gchar *text, gint offset)
{
 GeditTab *t = gedit_window_create_tab (w, TRUE);
 GtkTextBuffer *b = GTK_TEXT_BUFFER (gedit_tab_get_document (t));
 GtkTextIter it;
 gtk_text_buffer_set_text (b, text, -1);
 gtk_text_buffer_get_iter_at_offset (b, &it, offset);
 gtk_text_buffer_place_cursor (b, &it);
 return t;
}
static GtkDialog *dialog (GeditWindow *w)
{
 GList *list = gtk_window_list_toplevels (), *l;
 GtkDialog *result = NULL;
 for (l = list; l; l = l->next)
  if (GTK_IS_DIALOG (l->data) && gtk_window_get_transient_for (l->data) == GTK_WINDOW (w))
   result = l->data;
 g_list_free (list);
 return result;
}
static void check (GeditTab *t, const gchar *expected, gint offset)
{
 GtkTextBuffer *b = GTK_TEXT_BUFFER (gedit_tab_get_document (t));
 GtkTextIter a, z, c;
 gchar *text;
 gtk_text_buffer_get_bounds (b, &a, &z);
 text = gtk_text_buffer_get_text (b, &a, &z, TRUE);
 g_assert_cmpstr (text, ==, expected);
 gtk_text_buffer_get_iter_at_mark (b, &c, gtk_text_buffer_get_insert (b));
 g_assert_cmpint (gtk_text_iter_get_offset (&c), ==, offset);
 g_free (text);
}
static gboolean saved = FALSE;
static void save_done (GObject *source, GAsyncResult *result, gpointer data)
{
 saved = _gedit_tab_save_finish (GEDIT_TAB (source), result);
}
int main (int argc, char **argv)
{
 GeditApp *app;
 GError *error = NULL;
 GeditFactory *factory;
 GList *windows, *tabs;
 GeditWindow *w;
 const gchar *mode = argv[1];
 gtk_init (&argc, &argv);
 gedit_dirs_init ();
 tepl_init ();
 factory = gedit_factory_new ();
 tepl_abstract_factory_set_singleton (TEPL_ABSTRACT_FACTORY (factory));
 app = g_object_new (GEDIT_TYPE_APP, "application-id", "org.gnome.gedit.DraftTests",
                     "flags", G_APPLICATION_NON_UNIQUE, NULL);
 g_application_set_resource_base_path (G_APPLICATION (app), "/org/gnome/gedit");
 g_assert_true (g_application_register (G_APPLICATION (app), NULL, &error));
 if (g_str_has_prefix (mode, "seed"))
 {
  GeditTab *a, *named;
  GFile *file;
 w = gedit_app_create_window (app, NULL);
  gtk_widget_show (GTK_WIDGET (w));
  drain ();
  a = add (w, "first α\nline two", 8);
  named = add (w, "modified named", 3);
  file = g_file_new_for_path ("/tmp/gedit-draft-test-named.txt");
  g_file_set_contents ("/tmp/gedit-draft-test-named.txt", "on disk", -1, NULL);
  gtk_source_file_set_location (gedit_document_get_file (gedit_tab_get_document (named)), file);
  g_object_unref (file);
  add (w, "second β", 4);
  gedit_window_set_active_tab (w, a);
  drain ();
  _gedit_cmd_file_close_window (w);
  g_assert_nonnull (dialog (w));
  g_assert_true (GEDIT_IS_CLOSE_CONFIRMATION_DIALOG (dialog (w)));
  tabs = gedit_window_get_documents (w);
  g_assert_cmpint (g_list_length (tabs), ==, 3);
  g_list_free (tabs);
  /* Only the named document must be in the normal confirmation. */
  g_assert_cmpint (g_list_length ((GList *)gedit_close_confirmation_dialog_get_unsaved_documents
                                 (GEDIT_CLOSE_CONFIRMATION_DIALOG (dialog (w)))), ==, 1);
  gtk_dialog_response (dialog (w), GTK_RESPONSE_CANCEL);
  tabs = gedit_window_get_documents (w);
  g_assert_cmpint (g_list_length (tabs), ==, 3);
  g_list_free (tabs);
  check (a, "first α\nline two", 8);
  if (g_str_equal (mode, "seed-draft-active"))
   gedit_window_set_active_tab (w, a);
  _gedit_cmd_file_close_window (w);
  gtk_dialog_response (dialog (w), GTK_RESPONSE_NO);
  drain ();
 w = gedit_app_create_window (app, NULL);
  gtk_widget_show (GTK_WIDGET (w));
  drain ();
  add (w, "other window", 5);
  add (w, "", 0);
  _gedit_cmd_file_quit (NULL, NULL, app);
  drain ();
  windows = gedit_app_get_main_windows (app);
  g_assert_null (windows);
  g_print ("PASS mixed named/untitled, named-only prompt, Cancel retains all tabs, two-window Quit\n");
 }
 else if (g_str_equal (mode, "restore"))
 {
  gint seen = 0;
  g_application_activate (G_APPLICATION (app));
  windows = gedit_app_get_main_windows (app);
  g_assert_cmpint (g_list_length (windows), ==, 2);
  for (GList *l = windows; l; l = l->next)
  {
   w = l->data;
   tabs = all_tabs (w);
   GeditTab *first = tabs->data;
   GtkTextBuffer *b = GTK_TEXT_BUFFER (gedit_tab_get_document (first));
   GtkTextIter start, end;
   gtk_text_buffer_get_bounds (b, &start, &end);
   gchar *text = gtk_text_buffer_get_text (b, &start, &end, TRUE);
   if (g_str_has_prefix (text, "first"))
   {
    check (first, "first α\nline two", 8);
    g_assert_cmpint (g_list_length (tabs), ==, 3);
    check (tabs->next->next->data, "second β", 4);
    GeditTab *expected_active = g_getenv ("DRAFT_TEST_ACTIVE") ? first : tabs->next->data;
    g_assert_true (gedit_window_get_active_tab (w) == expected_active);
    gint64 deadline = g_get_monotonic_time () + 10 * G_TIME_SPAN_SECOND;
    while (gedit_tab_get_state (tabs->next->data) == GEDIT_TAB_STATE_LOADING &&
           g_get_monotonic_time () < deadline) g_main_context_iteration (NULL, TRUE);
    check (tabs->next->data, "on disk", 3);
    g_assert_true (gedit_window_get_active_tab (w) == expected_active);
    seen |= 1;
   }
   else
   {
    g_assert_cmpint (g_list_length (tabs), ==, 2);
    check (first, "other window", 5);
    check (tabs->next->data, "", 0);
    g_assert_true (gedit_window_get_active_tab (w) == tabs->next->data);
    seen |= 2;
   }
   g_free (text);
   g_list_free (tabs);
  }
  g_assert_cmpint (seen, ==, 3);
  g_list_free (windows);
  g_print ("PASS fresh-process restoration: Unicode text, order, cursors, active tabs, blank draft, two windows\n");
 }
 else if (g_str_equal (mode, "save-discard"))
 {
  gedit_drafts_restore (app);
  windows = gedit_app_get_main_windows (app);
  w = windows->data;
  for (GList *l = windows; l; l = l->next)
  {
   GList *docs = gedit_window_get_documents (l->data);
   if (g_list_length (docs) == 2) w = l->data;
   g_list_free (docs);
  }
  tabs = all_tabs (w);
  GeditTab *first = tabs->data;
  GeditDocument *doc = gedit_tab_get_document (first);
  GFile *file = g_file_new_for_path ("/tmp/gedit-restored-saved.txt");
  _gedit_tab_save_as_async (first, file, gtk_source_encoding_new_utf8 (),
                           GTK_SOURCE_NEWLINE_TYPE_LF, GTK_SOURCE_COMPRESSION_TYPE_NONE,
                           NULL, save_done, NULL);
  gint64 deadline = g_get_monotonic_time () + 10 * G_TIME_SPAN_SECOND;
  while (!saved && g_get_monotonic_time () < deadline) g_main_context_iteration (NULL, TRUE);
  g_assert_true (saved);
  g_assert_false ((gtk_source_file_get_location (gedit_document_get_file (doc)) == NULL));
  g_assert_null (g_object_get_data (G_OBJECT (doc), "draft-path"));
  GeditTab *second = tabs->next->data;
  gtk_text_buffer_set_text (GTK_TEXT_BUFFER (gedit_tab_get_document (second)), "discard me", -1);
  _gedit_cmd_file_close_tab (second, w);
  g_assert_nonnull (dialog (w));
  gtk_dialog_response (dialog (w), GTK_RESPONSE_CANCEL);
  g_assert_true (gtk_widget_get_toplevel (GTK_WIDGET (second)) == GTK_WIDGET (w));
  _gedit_cmd_file_close_tab (second, w);
  gtk_dialog_response (dialog (w), GTK_RESPONSE_NO);
  g_list_free (tabs);
  g_list_free (windows);
  g_print ("PASS actual asynchronous Save As removes stored draft; individual tab Cancel and Discard\n");
 }
 else if (g_str_equal (mode, "after-cleanup"))
 {
  g_application_activate (G_APPLICATION (app));
  windows = gedit_app_get_main_windows (app);
  g_assert_cmpint (g_list_length (windows), ==, 1);
  w = windows->data;
  tabs = all_tabs (w);
  g_assert_cmpint (g_list_length (tabs), ==, 3);
  check (tabs->data, "first α\nline two", 8);
  check (tabs->next->next->data, "second β", 4);
  g_list_free (tabs);
  g_list_free (windows);
  g_print ("PASS fresh restart does not resurrect saved or discarded drafts\n");
 }
 else if (g_str_equal (mode, "toggle"))
 {
  GtkWidget *prefs;
  GtkToggleButton *toggle;
  GeditTab *draft;
  w = gedit_app_create_window (app, NULL);
  gtk_widget_show (GTK_WIDGET (w));
  drain ();
  draft = add (w, "keep until discarded", 6);
  g_assert_true (gedit_drafts_store (w));
  prefs = GTK_WIDGET (gedit_preferences_dialog_new ());
  gtk_widget_show_all (prefs);
  drain ();
  toggle = find_draft_toggle (prefs);
  g_assert_nonnull (toggle);
  g_assert_true (gtk_toggle_button_get_active (toggle));
  gtk_toggle_button_set_active (toggle, FALSE);
  g_assert_false (gedit_drafts_enabled ());
  gtk_toggle_button_set_active (toggle, TRUE);
  g_assert_true (gedit_drafts_enabled ());
  gtk_toggle_button_set_active (toggle, FALSE);
  drain ();
  gtk_widget_destroy (prefs);
  drain ();
  /* Changing the checkbox persists after the preferences dialog closes. */
  g_assert_false (gedit_drafts_enabled ());
  _gedit_cmd_file_close_window (w);
  g_assert_nonnull (dialog (w));
  g_assert_true (GEDIT_IS_CLOSE_CONFIRMATION_DIALOG (dialog (w)));
  gtk_dialog_response (dialog (w), GTK_RESPONSE_CANCEL);
  check (draft, "keep until discarded", 6);
  g_assert_true (gtk_widget_get_toplevel (GTK_WIDGET (draft)) == GTK_WIDGET (w));
  _gedit_cmd_file_quit (NULL, NULL, app);
  g_assert_nonnull (dialog (w));
  gtk_dialog_response (dialog (w), GTK_RESPONSE_NO);
  drain ();
  windows = gedit_app_get_main_windows (app);
  g_assert_null (windows);
  g_print ("PASS preference checkbox, enabled/disabled binding, disabled close Cancel and Quit Discard\n");
 }
 else if (g_str_equal (mode, "toggle-after-discard"))
 {
  g_application_activate (G_APPLICATION (app));
  windows = gedit_app_get_main_windows (app);
  g_assert_cmpint (g_list_length (windows), ==, 1);
  w = windows->data;
  tabs = all_tabs (w);
  g_assert_cmpint (g_list_length (tabs), ==, 1);
  check (tabs->data, "", 0);
  g_assert_null (g_object_get_data (G_OBJECT (gedit_tab_get_document (tabs->data)), "draft-path"));
  g_list_free (tabs);
  g_list_free (windows);
  g_print ("PASS disabled-mode Discard removes old stored draft across a restart\n");
 }
 else if (g_str_equal (mode, "failure"))
 {
 w = gedit_app_create_window (app, NULL);
  gtk_widget_show (GTK_WIDGET (w));
  drain ();
  GeditTab *t = add (w, "must survive failed storage", 7);
  g_object_set_data_full (G_OBJECT (w), "draft-path", g_strdup ("/proc/gedit-drafts-impossible.ini"), g_free);
  _gedit_cmd_file_close_window (w);
  g_assert_nonnull (dialog (w));
  g_assert_true (GTK_IS_MESSAGE_DIALOG (dialog (w)));
  g_assert_true (gtk_widget_get_toplevel (GTK_WIDGET (t)) == GTK_WIDGET (w));
  check (t, "must survive failed storage", 7);
  gtk_dialog_response (dialog (w), GTK_RESPONSE_CLOSE);
  g_print ("PASS storage failure displays error and retains document and window\n");
 }
 else g_error ("unknown test mode");
 return 0;
}
