/* SPDX-FileCopyrightText: 2023 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#include "gedit-header-bar.h"
#include <glib/gi18n.h>
#include "gedit-app-private.h"
#include "gedit-commands.h"
#include "gedit-window-private.h"
#include "gedit-side-panel.h"
#include "gedit-plugins-engine.h"
#include "gedit-message-bus.h"

struct _GeditHeaderBarPrivate
{
	/* Weak ref */
	GeditWindow *window;

	/* Part of the GtkHeaderBar */
	GtkMenuButton *open_recent_menu_button;
	GtkMenuButton *hamburger_menu_button;
};

G_DEFINE_TYPE_WITH_PRIVATE (GeditHeaderBar, _gedit_header_bar, GTK_TYPE_HEADER_BAR)

static void
_gedit_header_bar_dispose (GObject *object)
{
	GeditHeaderBar *bar = GEDIT_HEADER_BAR (object);

	g_clear_weak_pointer (&bar->priv->window);
	bar->priv->open_recent_menu_button = NULL;
	bar->priv->hamburger_menu_button = NULL;

	G_OBJECT_CLASS (_gedit_header_bar_parent_class)->dispose (object);
}

static void
_gedit_header_bar_class_init (GeditHeaderBarClass *klass)
{
	GObjectClass *object_class = G_OBJECT_CLASS (klass);

	object_class->dispose = _gedit_header_bar_dispose;
}

static void
_gedit_header_bar_init (GeditHeaderBar *bar)
{
	bar->priv = _gedit_header_bar_get_instance_private (bar);
}

static GtkWidget *
create_open_dialog_button (void)
{
	GtkWidget *button;

	button = gtk_button_new_with_mnemonic (_("_Open"));
	gtk_widget_set_tooltip_text (button, _("Open a file"));
	gtk_actionable_set_action_name (GTK_ACTIONABLE (button), "win.open");

	return button;
}

static void
open_recent_menu_item_activated_cb (GtkRecentChooser *recent_chooser,
				    gpointer          user_data)
{
	GeditHeaderBar *bar = GEDIT_HEADER_BAR (user_data);
	gchar *uri;
	GFile *location;

	if (bar->priv->window == NULL)
	{
		return;
	}

	uri = gtk_recent_chooser_get_current_uri (recent_chooser);
	location = g_file_new_for_uri (uri);

	gedit_commands_load_location (bar->priv->window, location, NULL, 0, 0);

	g_free (uri);
	g_object_unref (location);
}

static void
workspace_response_cb (GtkDialog *chooser, gint response, GeditHeaderBar *bar)
{
	PeasEngine *engine;
	PeasPluginInfo *plugin;
	GeditSidePanel *side_panel;
	GeditMessageBus *bus;
	GeditMessage *message;
	GFile *root;

	if (response != GTK_RESPONSE_ACCEPT || bar->priv->window == NULL)
	{
		gtk_widget_destroy (GTK_WIDGET (chooser));
		return;
	}
	root = gtk_file_chooser_get_file (GTK_FILE_CHOOSER (chooser));
	if (root == NULL)
		return;

	engine = PEAS_ENGINE (gedit_plugins_engine_get_default ());
	plugin = peas_engine_get_plugin_info (engine, "filebrowser");
	if (plugin == NULL || !peas_engine_load_plugin (engine, plugin))
	{
		GtkWidget *dialog = gtk_message_dialog_new (GTK_WINDOW (bar->priv->window),
			GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR, GTK_BUTTONS_CLOSE,
			"%s", _("The File Browser plugin could not be loaded."));
		g_signal_connect_swapped (dialog, "response", G_CALLBACK (gtk_widget_destroy), dialog);
		gtk_widget_show (dialog);
		g_object_unref (root);
		gtk_widget_destroy (GTK_WIDGET (chooser));
		return;
	}

	bus = gedit_window_get_message_bus (bar->priv->window);
	message = gedit_message_bus_send_sync (bus, "/plugins/filebrowser", "set_root", "location", root, NULL);
	g_clear_object (&message);
	g_clear_object (&root);

	side_panel = _gedit_window_get_whole_side_panel (bar->priv->window);
	tepl_panel_simple_set_active_item_name (_gedit_side_panel_get_panel_simple (side_panel), "GeditFileBrowserPanel");
	gtk_widget_show (GTK_WIDGET (side_panel));
	gtk_widget_destroy (GTK_WIDGET (chooser));
}


static void
open_workspace_cb (GtkMenuItem *item, GeditHeaderBar *bar)
{
	GtkWidget *chooser;
	GFile *root = NULL;
	GeditMessageBus *bus;
	if (bar->priv->window == NULL)
		return;
	bus = gedit_window_get_message_bus (bar->priv->window);
	if (gedit_message_bus_is_registered (bus, "/plugins/filebrowser", "get_root"))
	{
		GeditMessage *message = gedit_message_bus_send_sync (bus, "/plugins/filebrowser", "get_root", NULL);
		if (message != NULL)
		{
			g_object_get (message, "location", &root, NULL);
			g_object_unref (message);
		}
	}
	chooser = gtk_file_chooser_dialog_new (_("Select Workspace"), GTK_WINDOW (bar->priv->window),
		GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER, _("_Cancel"), GTK_RESPONSE_CANCEL,
		_("_Select"), GTK_RESPONSE_ACCEPT, NULL);
	gtk_window_set_modal (GTK_WINDOW (chooser), TRUE);
	gtk_window_set_destroy_with_parent (GTK_WINDOW (chooser), TRUE);
	gtk_file_chooser_set_create_folders (GTK_FILE_CHOOSER (chooser), FALSE);
	if (root == NULL)
		root = g_file_new_for_path (g_get_home_dir ());
	gtk_file_chooser_set_current_folder_file (GTK_FILE_CHOOSER (chooser), root, NULL);
	g_object_unref (root);
	g_signal_connect_object (chooser, "response", G_CALLBACK (workspace_response_cb), bar, 0);
	gtk_widget_show (chooser);
}

static void
create_open_recent_menu_button (GeditHeaderBar *bar)
{
	GtkRecentChooserMenu *recent_menu;
	GtkWidget *workspace_item;
	GtkWidget *separator;
	AmtkApplicationWindow *amtk_window;

	g_return_if_fail (bar->priv->open_recent_menu_button == NULL);

	bar->priv->open_recent_menu_button = GTK_MENU_BUTTON (gtk_menu_button_new ());
	gtk_widget_set_tooltip_text (GTK_WIDGET (bar->priv->open_recent_menu_button),
				     _("Open a recent file or workspace"));

	recent_menu = amtk_application_window_create_open_recent_menu_base ();
	separator = gtk_separator_menu_item_new ();
	workspace_item = gtk_menu_item_new_with_mnemonic (_("_Workspace"));
	gtk_menu_shell_prepend (GTK_MENU_SHELL (recent_menu), separator);
	gtk_menu_shell_prepend (GTK_MENU_SHELL (recent_menu), workspace_item);
	gtk_widget_show (separator);
	gtk_widget_show (workspace_item);
	g_signal_connect_object (workspace_item, "activate", G_CALLBACK (open_workspace_cb), bar, 0);

	amtk_window = amtk_application_window_get_from_gtk_application_window (GTK_APPLICATION_WINDOW (bar->priv->window));
	amtk_application_window_connect_recent_chooser_menu_to_statusbar (amtk_window, recent_menu);

	g_signal_connect_object (recent_menu,
				 "item-activated",
				 G_CALLBACK (open_recent_menu_item_activated_cb),
				 bar,
				 G_CONNECT_DEFAULT);

	gtk_menu_button_set_popup (bar->priv->open_recent_menu_button,
				   GTK_WIDGET (recent_menu));
}

static void
add_open_buttons (GeditHeaderBar *bar)
{
	GtkWidget *hbox;
	GtkStyleContext *style_context;

	create_open_recent_menu_button (bar);

	/* It currently needs to be a GtkBox, not a GtkGrid, because GtkGrid and
	 * GTK_STYLE_CLASS_LINKED doesn't work as expected in a RTL locale.
	 * Probably a GtkGrid bug.
	 */
	hbox = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
	style_context = gtk_widget_get_style_context (hbox);
	gtk_style_context_add_class (style_context, GTK_STYLE_CLASS_LINKED);

	gtk_container_add (GTK_CONTAINER (hbox), create_open_dialog_button ());
	gtk_container_add (GTK_CONTAINER (hbox), GTK_WIDGET (bar->priv->open_recent_menu_button));
	gtk_widget_show_all (hbox);

	gtk_header_bar_pack_start (GTK_HEADER_BAR (bar), hbox);
}

static void
add_new_tab_button (GeditHeaderBar *bar)
{
	GtkWidget *button;

	button = gtk_button_new_from_icon_name ("tab-new-symbolic", GTK_ICON_SIZE_BUTTON);
	gtk_widget_set_tooltip_text (button, _("Create a new document"));
	gtk_actionable_set_action_name (GTK_ACTIONABLE (button), "win.new-tab");
	gtk_widget_show (button);

	gtk_header_bar_pack_start (GTK_HEADER_BAR (bar), button);
}

static void
add_leave_fullscreen_button (GeditHeaderBar *bar)
{
	GtkWidget *button;

	button = gtk_button_new_from_icon_name ("view-restore-symbolic", GTK_ICON_SIZE_BUTTON);
	gtk_widget_set_tooltip_text (button, _("Leave Fullscreen"));
	gtk_actionable_set_action_name (GTK_ACTIONABLE (button), "win.leave-fullscreen");
	gtk_widget_show (button);

	gtk_header_bar_pack_end (GTK_HEADER_BAR (bar), button);
}

static void
add_hamburger_menu_button (GeditHeaderBar *bar)
{
	GMenuModel *hamburger_menu;

	g_return_if_fail (bar->priv->hamburger_menu_button == NULL);

	hamburger_menu = _gedit_app_get_hamburger_menu (GEDIT_APP (g_application_get_default ()));

	if (hamburger_menu == NULL)
	{
		return;
	}

	bar->priv->hamburger_menu_button = GTK_MENU_BUTTON (gtk_menu_button_new ());
	gtk_menu_button_set_direction (bar->priv->hamburger_menu_button, GTK_ARROW_NONE);
	gtk_menu_button_set_menu_model (bar->priv->hamburger_menu_button, hamburger_menu);
	gtk_widget_show (GTK_WIDGET (bar->priv->hamburger_menu_button));

	gtk_header_bar_pack_end (GTK_HEADER_BAR (bar),
				 GTK_WIDGET (bar->priv->hamburger_menu_button));
}

static void
add_save_button (GeditHeaderBar *bar)
{
	GtkWidget *button;

	button = gtk_button_new_with_mnemonic (_("_Save"));
	gtk_widget_set_tooltip_text (button, _("Save the current file"));
	gtk_actionable_set_action_name (GTK_ACTIONABLE (button), "win.save");
	gtk_widget_show (button);

	gtk_header_bar_pack_end (GTK_HEADER_BAR (bar), button);
}

static void
setup_title_area (GeditHeaderBar *bar)
{
	GtkWidget *spacer;

	/* Document titles belong in the always-visible tab strip. Keep the
	 * native window title for task switching, but leave the header blank.
	 */
	spacer = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_widget_show (spacer);
	gtk_header_bar_set_custom_title (GTK_HEADER_BAR (bar), spacer);
	gtk_header_bar_set_has_subtitle (GTK_HEADER_BAR (bar), FALSE);
}

GeditHeaderBar *
_gedit_header_bar_new (GeditWindow *window,
		       gboolean     fullscreen)
{
	GeditHeaderBar *bar;

	g_return_val_if_fail (GEDIT_IS_WINDOW (window), NULL);

	bar = g_object_new (GEDIT_TYPE_HEADER_BAR, NULL);

	g_set_weak_pointer (&bar->priv->window, window);

	add_open_buttons (bar);
	add_new_tab_button (bar);

	if (fullscreen)
	{
		add_leave_fullscreen_button (bar);
	}

	add_hamburger_menu_button (bar);
	add_save_button (bar);

	setup_title_area (bar);

	return bar;
}

GtkMenuButton *
_gedit_header_bar_get_open_recent_menu_button (GeditHeaderBar *bar)
{
	g_return_val_if_fail (GEDIT_IS_HEADER_BAR (bar), NULL);
	return bar->priv->open_recent_menu_button;
}

GtkMenuButton *
_gedit_header_bar_get_hamburger_menu_button (GeditHeaderBar *bar)
{
	g_return_val_if_fail (GEDIT_IS_HEADER_BAR (bar), NULL);
	return bar->priv->hamburger_menu_button;
}
