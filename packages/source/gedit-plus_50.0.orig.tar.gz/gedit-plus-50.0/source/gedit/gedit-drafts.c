/* Persistent untitled documents. GPL-3.0-or-later. */
#include "config.h"
#include "gedit-drafts.h"
#include "gedit-window-private.h"
#include "gedit-document-private.h"
#include <glib/gstdio.h>

/* Load only our additional schema locally, keeping the system preferences
 * schemas and the user's existing settings unchanged.
 */
GSettings *
gedit_drafts_get_settings (void)
{
	GSettingsSchemaSource *source;
	GSettingsSchema *schema;
	GSettings *settings;
	GError *error = NULL;

	source = g_settings_schema_source_new_from_directory (
		g_getenv ("GSETTINGS_SCHEMA_DIR") ? g_getenv ("GSETTINGS_SCHEMA_DIR") : DATADIR "/glib-2.0/schemas",
		g_settings_schema_source_get_default (), FALSE, &error);
	if (source == NULL)
		g_error ("Cannot load draft preferences: %s", error->message);
	schema = g_settings_schema_source_lookup (source, "org.gnome.gedit.preferences.drafts", TRUE);
	if (schema == NULL)
		g_error ("The draft preferences schema is not installed");
	settings = g_settings_new_full (schema, NULL, NULL);
	g_settings_schema_unref (schema);
	g_settings_schema_source_unref (source);
	return settings;
}

gboolean
gedit_drafts_enabled (void)
{
	GSettings *settings = gedit_drafts_get_settings ();
	gboolean enabled = g_settings_get_boolean (settings, "preserve-on-close");
	g_object_unref (settings);
	return enabled;
}

static gchar *
draft_directory (void)
{
	return g_build_filename (g_get_user_data_dir (), "gedit", "drafts-v1", NULL);
}

static void
report_error (GeditWindow *window, GError *error)
{
	GtkWidget *dialog = gtk_message_dialog_new (GTK_WINDOW (window),
		GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR, GTK_BUTTONS_CLOSE,
		"Draft storage error");
	gtk_message_dialog_format_secondary_text (GTK_MESSAGE_DIALOG (dialog), "%s", error->message);
	g_signal_connect_swapped (dialog, "response", G_CALLBACK (gtk_widget_destroy), dialog);
	gtk_widget_show (dialog);
}

static gboolean
write_keyfile (GKeyFile *keyfile, const gchar *path, GError **error)
{
	gsize size;
	gchar *data = g_key_file_to_data (keyfile, &size, NULL);
	gboolean ok = g_file_set_contents_full (path, data, size,
		G_FILE_SET_CONTENTS_CONSISTENT | G_FILE_SET_CONTENTS_DURABLE, 0600, error);
	g_free (data);
	return ok;
}

static void
saved_cb (GeditDocument *doc, gpointer user_data)
{
	GeditTab *tab = gedit_tab_get_from_document (doc);
	GtkWidget *window = gtk_widget_get_toplevel (GTK_WIDGET (tab));
	if (!_gedit_document_is_untitled (doc) && GEDIT_IS_WINDOW (window))
		gedit_drafts_forget (doc, GEDIT_WINDOW (window));
}

gboolean
gedit_drafts_store (GeditWindow *window)
{
	gchar *dir = draft_directory ();
	const gchar *path = g_object_get_data (G_OBJECT (window), "draft-path");
	GKeyFile *keyfile = g_key_file_new ();
	GList *tabs = _gedit_window_get_all_tabs (window), *l;
	GError *error = NULL;
	gint index = 0, active = 0, drafts = 0;
	gboolean ok;

	/* A window containing only named files needs no draft storage. */
	if (path == NULL)
	{
		gboolean has_untitled = FALSE;
		for (l = tabs; l != NULL; l = l->next)
			has_untitled |= _gedit_document_is_untitled (gedit_tab_get_document (l->data));
		if (!has_untitled)
		{
			g_key_file_unref (keyfile);
			g_list_free (tabs);
			g_free (dir);
			return TRUE;
		}
	}

	if (g_mkdir_with_parents (dir, 0700) != 0)
	{
		g_set_error (&error, G_FILE_ERROR, g_file_error_from_errno (errno),
			"Cannot create draft directory: %s", g_strerror (errno));
		goto failure;
	}
	if (path == NULL)
	{
		gchar *id = g_uuid_string_random ();
		gchar *name = g_strconcat (id, ".ini", NULL);
		g_object_set_data_full (G_OBJECT (window), "draft-path",
			g_build_filename (dir, name, NULL), g_free);
		path = g_object_get_data (G_OBJECT (window), "draft-path");
		g_free (id);
		g_free (name);
	}
	for (l = tabs; l != NULL; l = l->next)
	{
		GeditTab *tab = l->data;
		GeditDocument *doc = gedit_tab_get_document (tab);
		GtkTextBuffer *buffer = GTK_TEXT_BUFFER (doc);
		GtkTextIter start, end, cursor;
		gchar *group, *text;
		group = g_strdup_printf ("draft-%d", index);
		if (tab == gedit_window_get_active_tab (window))
			active = index;
		gtk_text_buffer_get_bounds (buffer, &start, &end);
		text = gtk_text_buffer_get_text (buffer, &start, &end, TRUE);
		gtk_text_buffer_get_iter_at_mark (buffer, &cursor, gtk_text_buffer_get_insert (buffer));
		if (_gedit_document_is_untitled (doc))
		{
			g_key_file_set_string (keyfile, group, "text", text);
			drafts++;
		}
		else
		{
			gchar *uri = g_file_get_uri (gtk_source_file_get_location (gedit_document_get_file (doc)));
			g_key_file_set_string (keyfile, group, "uri", uri);
			g_key_file_set_integer (keyfile, group, "line", gtk_text_iter_get_line (&cursor) + 1);
			g_key_file_set_integer (keyfile, group, "column", gtk_text_iter_get_line_offset (&cursor) + 1);
			g_free (uri);
		}
		g_key_file_set_integer (keyfile, group, "cursor", gtk_text_iter_get_offset (&cursor));
		g_free (group);
		g_free (text);
		index++;
	}
	g_key_file_set_integer (keyfile, "window", "count", drafts > 0 ? index : 0);
	g_key_file_set_integer (keyfile, "window", "active", active);
	ok = write_keyfile (keyfile, path, &error);
	if (!ok)
		goto failure;
	/* Publish document identities only after the complete snapshot is durable. */
	index = 0;
	for (l = tabs; l != NULL; l = l->next)
	{
		GeditDocument *doc = gedit_tab_get_document (l->data);
		if (!_gedit_document_is_untitled (doc))
		{
			index++;
			continue;
		}
		g_object_set_data_full (G_OBJECT (doc), "draft-group",
			g_strdup_printf ("draft-%d", index++), g_free);
		g_object_set_data_full (G_OBJECT (doc), "draft-path", g_strdup (path), g_free);
		if (!g_object_get_data (G_OBJECT (doc), "draft-saved-handler"))
		{
			g_signal_connect (doc, "saved", G_CALLBACK (saved_cb), NULL);
			g_object_set_data (G_OBJECT (doc), "draft-saved-handler", GINT_TO_POINTER (1));
		}
	}
	g_key_file_unref (keyfile);
	g_list_free (tabs);
	g_free (dir);
	return TRUE;
failure:
	report_error (window, error);
	g_clear_error (&error);
	g_key_file_unref (keyfile);
	g_list_free (tabs);
	g_free (dir);
	return FALSE;
}

gboolean
gedit_drafts_forget (GeditDocument *doc, GeditWindow *window)
{
	const gchar *path = g_object_get_data (G_OBJECT (doc), "draft-path");
	const gchar *group = g_object_get_data (G_OBJECT (doc), "draft-group");
	GKeyFile *keyfile;
	GError *error = NULL;
	gboolean ok;
	if (path == NULL || group == NULL)
		return TRUE;
	keyfile = g_key_file_new ();
	ok = g_key_file_load_from_file (keyfile, path, G_KEY_FILE_NONE, &error);
	if (ok)
	{
		g_key_file_remove_group (keyfile, group, NULL);
		ok = write_keyfile (keyfile, path, &error);
	}
	if (!ok)
		report_error (window, error);
	else
	{
		g_object_set_data (G_OBJECT (doc), "draft-path", NULL);
		g_object_set_data (G_OBJECT (doc), "draft-group", NULL);
	}
	g_clear_error (&error);
	g_key_file_unref (keyfile);
	return ok;
}

void
gedit_drafts_restore (GeditApp *app)
{
	gchar *dir = draft_directory ();
	GDir *directory;
	const gchar *name;
	if (g_object_get_data (G_OBJECT (app), "drafts-restored"))
	{
		g_free (dir);
		return;
	}
	g_object_set_data (G_OBJECT (app), "drafts-restored", GINT_TO_POINTER (1));
	directory = g_dir_open (dir, 0, NULL);
	while (directory != NULL && (name = g_dir_read_name (directory)) != NULL)
	{
		gchar *path;
		GKeyFile *keyfile;
		GeditWindow *window = NULL;
		GeditTab *active_tab = NULL;
		gint count, active, i;
		GError *error = NULL;
		if (!g_str_has_suffix (name, ".ini"))
			continue;
		path = g_build_filename (dir, name, NULL);
		keyfile = g_key_file_new ();
		if (!g_key_file_load_from_file (keyfile, path, G_KEY_FILE_NONE, &error))
		{
			window = gedit_app_create_window (app, NULL);
			gtk_widget_show (GTK_WIDGET (window));
			report_error (window, error);
			g_clear_error (&error);
			goto next;
		}
		/* Named files are layout references; a session exists only while it has drafts. */
		{
			gchar **groups = g_key_file_get_groups (keyfile, NULL);
			gboolean has_draft = FALSE;
			for (guint j = 0; groups[j] != NULL; j++)
				has_draft |= g_key_file_has_key (keyfile, groups[j], "text", NULL);
			g_strfreev (groups);
			if (!has_draft)
				goto next;
		}
		count = g_key_file_get_integer (keyfile, "window", "count", NULL);
		active = g_key_file_get_integer (keyfile, "window", "active", NULL);
		for (i = 0; i < count; i++)
		{
			gchar *group = g_strdup_printf ("draft-%d", i);
			gchar *text = g_key_file_get_string (keyfile, group, "text", NULL);
			gchar *uri = g_key_file_get_string (keyfile, group, "uri", NULL);
			GeditTab *tab;
			GeditDocument *doc;
			GtkTextIter cursor;
			gint offset;
			if (text == NULL && uri == NULL)
			{
				g_free (group);
				continue;
			}
			if (window == NULL)
			{
				window = gedit_app_create_window (app, NULL);
				g_object_set_data_full (G_OBJECT (window), "draft-path", g_strdup (path), g_free);
			}
			tab = gedit_window_create_tab (window, TRUE);
			doc = gedit_tab_get_document (tab);
			if (uri != NULL)
			{
				GFile *file = g_file_new_for_uri (uri);
				gedit_tab_load_file (tab, file, NULL,
					g_key_file_get_integer (keyfile, group, "line", NULL),
					g_key_file_get_integer (keyfile, group, "column", NULL), FALSE);
				g_object_unref (file);
				g_free (uri);
				g_free (group);
				if (i == active || active_tab == NULL)
					active_tab = tab;
				continue;
			}
			gtk_text_buffer_set_text (GTK_TEXT_BUFFER (doc), text, -1);
			offset = g_key_file_get_integer (keyfile, group, "cursor", NULL);
			gtk_text_buffer_get_iter_at_offset (GTK_TEXT_BUFFER (doc), &cursor,
				CLAMP (offset, 0, gtk_text_buffer_get_char_count (GTK_TEXT_BUFFER (doc))));
			gtk_text_buffer_place_cursor (GTK_TEXT_BUFFER (doc), &cursor);
			g_object_set_data_full (G_OBJECT (doc), "draft-path", g_strdup (path), g_free);
			g_object_set_data_full (G_OBJECT (doc), "draft-group", group, g_free);
			g_signal_connect (doc, "saved", G_CALLBACK (saved_cb), NULL);
			g_object_set_data (G_OBJECT (doc), "draft-saved-handler", GINT_TO_POINTER (1));
			if (i == active || active_tab == NULL)
				active_tab = tab;
			g_free (text);
		}
		if (window != NULL)
		{
			if (active_tab != NULL)
				gedit_window_set_active_tab (window, active_tab);
			gtk_widget_show (GTK_WIDGET (window));
		}
next:
		g_key_file_unref (keyfile);
		g_free (path);
	}
	if (directory != NULL)
		g_dir_close (directory);
	g_free (dir);
}
