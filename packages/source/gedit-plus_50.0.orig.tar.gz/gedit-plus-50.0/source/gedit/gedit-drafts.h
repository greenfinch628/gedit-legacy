#pragma once
#include "gedit-app.h"
#include "gedit-window.h"
gboolean gedit_drafts_store (GeditWindow *window);
gboolean gedit_drafts_forget (GeditDocument *doc, GeditWindow *window);
void gedit_drafts_restore (GeditApp *app);
GSettings *gedit_drafts_get_settings (void);
gboolean gedit_drafts_enabled (void);
