/* SPDX-FileCopyrightText: 2025 - Sébastien Wilmet
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#pragma once

#include <libpeas/peas.h>

G_BEGIN_DECLS

#define GEDIT_TYPE_CODE_COMMENT_APP_ACTIVATABLE             (gedit_code_comment_app_activatable_get_type ())
#define GEDIT_CODE_COMMENT_APP_ACTIVATABLE(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), GEDIT_TYPE_CODE_COMMENT_APP_ACTIVATABLE, GeditCodeCommentAppActivatable))
#define GEDIT_CODE_COMMENT_APP_ACTIVATABLE_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), GEDIT_TYPE_CODE_COMMENT_APP_ACTIVATABLE, GeditCodeCommentAppActivatableClass))
#define GEDIT_IS_CODE_COMMENT_APP_ACTIVATABLE(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GEDIT_TYPE_CODE_COMMENT_APP_ACTIVATABLE))
#define GEDIT_IS_CODE_COMMENT_APP_ACTIVATABLE_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), GEDIT_TYPE_CODE_COMMENT_APP_ACTIVATABLE))
#define GEDIT_CODE_COMMENT_APP_ACTIVATABLE_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), GEDIT_TYPE_CODE_COMMENT_APP_ACTIVATABLE, GeditCodeCommentAppActivatableClass))

typedef struct _GeditCodeCommentAppActivatable         GeditCodeCommentAppActivatable;
typedef struct _GeditCodeCommentAppActivatableClass    GeditCodeCommentAppActivatableClass;
typedef struct _GeditCodeCommentAppActivatablePrivate  GeditCodeCommentAppActivatablePrivate;

struct _GeditCodeCommentAppActivatable
{
	GObject parent;

	GeditCodeCommentAppActivatablePrivate *priv;
};

struct _GeditCodeCommentAppActivatableClass
{
	GObjectClass parent_class;
};

GType	gedit_code_comment_app_activatable_get_type	(void);

void	gedit_code_comment_app_activatable_register	(PeasObjectModule *module);

G_END_DECLS
