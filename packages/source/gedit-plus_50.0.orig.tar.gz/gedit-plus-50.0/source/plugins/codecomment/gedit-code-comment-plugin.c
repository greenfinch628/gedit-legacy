/* SPDX-FileCopyrightText: 2025 - Sébastien Wilmet
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include "gedit-code-comment-plugin.h"
#include "gedit-code-comment-app-activatable.h"
#include "gedit-code-comment-window-activatable.h"
#include "gedit-code-comment-view-activatable.h"

G_MODULE_EXPORT void
peas_register_types (PeasObjectModule *module)
{
	gedit_code_comment_app_activatable_register (module);
	gedit_code_comment_window_activatable_register (module);
	gedit_code_comment_view_activatable_register (module);
}
