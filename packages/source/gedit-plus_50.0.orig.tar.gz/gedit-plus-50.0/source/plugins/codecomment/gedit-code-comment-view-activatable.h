/* SPDX-FileCopyrightText: 2025 - Sébastien Wilmet
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#pragma once

#include <libpeas/peas.h>

G_BEGIN_DECLS

#define GEDIT_TYPE_CODE_COMMENT_VIEW_ACTIVATABLE             (gedit_code_comment_view_activatable_get_type ())
#define GEDIT_CODE_COMMENT_VIEW_ACTIVATABLE(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), GEDIT_TYPE_CODE_COMMENT_VIEW_ACTIVATABLE, GeditCodeCommentViewActivatable))
#define GEDIT_CODE_COMMENT_VIEW_ACTIVATABLE_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), GEDIT_TYPE_CODE_COMMENT_VIEW_ACTIVATABLE, GeditCodeCommentViewActivatableClass))
#define GEDIT_IS_CODE_COMMENT_VIEW_ACTIVATABLE(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GEDIT_TYPE_CODE_COMMENT_VIEW_ACTIVATABLE))
#define GEDIT_IS_CODE_COMMENT_VIEW_ACTIVATABLE_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), GEDIT_TYPE_CODE_COMMENT_VIEW_ACTIVATABLE))
#define GEDIT_CODE_COMMENT_VIEW_ACTIVATABLE_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), GEDIT_TYPE_CODE_COMMENT_VIEW_ACTIVATABLE, GeditCodeCommentViewActivatableClass))

typedef struct _GeditCodeCommentViewActivatable         GeditCodeCommentViewActivatable;
typedef struct _GeditCodeCommentViewActivatableClass    GeditCodeCommentViewActivatableClass;
typedef struct _GeditCodeCommentViewActivatablePrivate  GeditCodeCommentViewActivatablePrivate;

struct _GeditCodeCommentViewActivatable
{
	GObject parent;

	GeditCodeCommentViewActivatablePrivate *priv;
};

struct _GeditCodeCommentViewActivatableClass
{
	GObjectClass parent_class;
};

GType	gedit_code_comment_view_activatable_get_type	(void);

void	gedit_code_comment_view_activatable_register	(PeasObjectModule *module);

G_END_DECLS
